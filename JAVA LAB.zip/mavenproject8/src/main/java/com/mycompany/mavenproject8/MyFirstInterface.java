package com.mycompany.mavenproject8;
public interface MyFirstInterface 
{
    
    int x=5;
    public void display();

}


//01.There are no different with or without in static final keyword add above approache.Because interface class already declre variable in static final keyword.

//02.There are no different method with or without in abstract keyword add above approache.Because interface class already declre abstract method use in abstract keyword.


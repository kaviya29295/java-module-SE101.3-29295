package com.mycompany.mavenproject8;
public class Mavenproject8 
{

    public static void main(String[] args) 
    {
        
    }
}

package com.mycompany.gui2;
public class GUI2 
{

    public static void main(String[] args) 
    {
        New2 c1=new New2();
        c1.show();
    }
}

package com.mycompany.shapemain;
public interface Shape 
{
    double calculateArea();
    double calculatePerimeter();
}

package com.mycompany.mavenproject9;
public class Undergraduate extends Student
{
    
}
        

    


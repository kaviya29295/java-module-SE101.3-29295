package com.mycompany.mavenproject9;
public class Mavenproject9 {

    public static void main(String[] args) 
    {
       //In this,Student class display method has not a body and in this student class is final because can not created sub class
    }
}

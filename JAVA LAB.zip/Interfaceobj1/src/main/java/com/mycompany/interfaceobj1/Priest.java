package com.mycompany.interfaceobj1;
public class Priest implements Speaker
{
    public void speak() 
   {
      //......
   }
    
}

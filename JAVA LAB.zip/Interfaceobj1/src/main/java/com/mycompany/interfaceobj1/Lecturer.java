package com.mycompany.interfaceobj1;
public class Lecturer  implements Speaker 
{
     public void speak() 
   {
      //......
   }
}

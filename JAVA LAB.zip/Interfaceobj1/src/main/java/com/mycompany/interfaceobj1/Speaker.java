package com.mycompany.interfaceobj1;

public interface Speaker 
{
    void speak();
}

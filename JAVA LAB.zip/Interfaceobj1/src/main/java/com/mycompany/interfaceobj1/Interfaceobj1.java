package com.mycompany.interfaceobj1;
public class Interfaceobj1 
{

    public static void main(String[] args) 
    {
        
    }
}

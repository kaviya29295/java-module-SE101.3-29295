package com.mycompany.movementobj;
public class Movementobj 
{

    public static void main(String[] args) 
    {
        Player p1=new Player();
        p1.moveup();
        p1.movedown();
        p1.moveleft();
        p1.moveright();
    }
}

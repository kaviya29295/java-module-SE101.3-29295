package com.mycompany.movementobj;
public abstract class Movement 
{
    public abstract void moveup();
    public abstract void movedown();
    public abstract void moveleft();
    public abstract void moveright();
}
